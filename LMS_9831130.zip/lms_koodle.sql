-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2022 at 10:35 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lms_koodle`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_id` int(8) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `prof_no` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course_name`, `prof_no`) VALUES
(12000001, 'اصول شبیه سازی', 12001),
(12000002, 'برنامه ریزی تولید', 12001),
(12000003, 'اصول بازاريابي', 12001),
(12000004, 'مديريت مالي', 12001),
(12000005, 'اقتصاد مهندسی', 12002),
(12000006, 'مديريت كيفيت و بهره وري', 12002),
(17000001, 'انتقال جرم', 17001),
(17000002, 'مکانیک سیالات ۱', 17001),
(17000003, 'عملیات واحد ۱', 17001),
(17000004, 'طرح و اقتصادکارخانه', 17002),
(17000005, 'موازنه انرژی ومواد', 17002),
(17000006, 'مکانیک سیالات ۱', 17002),
(26000001, 'مبانی مهندسی برق', 26001),
(26000002, 'سیستم‌های دیجیتال', 26001),
(26000003, 'الکترومغناطیس', 26001),
(26000004, 'سیستم‌های کنترل خطی', 26002),
(26000005, 'الکترونیک ۱', 26002),
(31000001, 'طراحي الگوريتم‌ها', 31001),
(31000002, 'جبر خطي کاربردي', 31001),
(31000003, 'مباني هوش محاسباتي', 31001),
(31000004, 'رياضيات گسسته', 31001),
(31000005, 'بازيابي اطلاعات', 31001),
(31000006, 'شبکه‌هاي کامپيوتري', 31002),
(31000007, 'داده کاوي', 31002),
(31000008, 'مهندسي نرم‌افزار ', 31003),
(31000009, 'اصول طراحي پايگاه داده‌ها', 31003),
(31000010, 'نظريه ‌زبان‌ها و ماشين‌ها', 31003),
(31000011, 'سيستم‌هاي عامل', 31004),
(31000012, 'مدارهاي منطقي', 31004),
(31000013, 'ساختمان داده‌ها ', 31004);

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `exam_id` int(11) NOT NULL,
  `exam_name` varchar(255) NOT NULL,
  `exam_starttime` datetime NOT NULL,
  `exam_finishtime` datetime NOT NULL,
  `lengh_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `course_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `exam_questions`
--

CREATE TABLE `exam_questions` (
  `exam_question_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `question_context` varchar(255) NOT NULL,
  `choice_1` varchar(255) NOT NULL,
  `choice_2` varchar(255) NOT NULL,
  `choice_3` varchar(255) NOT NULL,
  `choice_4` varchar(255) NOT NULL,
  `correct_choice` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `exam_question_answers`
--

CREATE TABLE `exam_question_answers` (
  `id` int(11) NOT NULL,
  `exam_question_id` int(11) NOT NULL,
  `student_no` int(11) NOT NULL,
  `answer` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `exam_student_score`
--

CREATE TABLE `exam_student_score` (
  `id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `student_no` int(11) NOT NULL,
  `exam_score` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `exercises`
--

CREATE TABLE `exercises` (
  `exercise_id` int(11) NOT NULL,
  `deadline` datetime NOT NULL,
  `exercise_name` varchar(255) NOT NULL,
  `course_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `exercises`
--

INSERT INTO `exercises` (`exercise_id`, `deadline`, `exercise_name`, `course_id`) VALUES
(1, '2022-06-30 11:30:50', 'Assignment 1', 31000006);

-- --------------------------------------------------------

--
-- Table structure for table `exercise_questions`
--

CREATE TABLE `exercise_questions` (
  `exercise_id` int(11) NOT NULL,
  `question_text` varchar(255) NOT NULL,
  `question_answer` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `exercise_question_answer`
--

CREATE TABLE `exercise_question_answer` (
  `exercise_id` int(11) NOT NULL,
  `answer` varchar(255) NOT NULL,
  `student_no` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `professors`
--

CREATE TABLE `professors` (
  `national_code` varchar(10) NOT NULL,
  `professor_no` int(5) NOT NULL,
  `father_name` varchar(255) NOT NULL,
  `birth_date` date NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `department` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` enum('ostad','ostad-yar','danesh-yar') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `professors`
--

INSERT INTO `professors` (`national_code`, `professor_no`, `father_name`, `birth_date`, `mobile`, `department`, `password`, `email`, `name`, `title`) VALUES
('3795148131', 12001, 'يحيي', '1340-01-15', '9972964000', 'مهندسی صنایع - مالی', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir', 'ابوالفضل - علیلو', 'danesh-yar'),
('9248312134', 12002, 'حسين', '1338-06-16', '9113890190', 'مهندسی صنایع - مالی', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir', 'محمد - نوائی', 'ostad-yar'),
('5874260383', 17001, 'قاسم ', '1354-04-14', '9960123300', 'مهندسی شیمی - پالایش', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir', 'حمید - آخوندی', 'ostad'),
('9843406062', 17002, 'حسين', '1352-04-05', '9932085747', 'مهندسی شیمی - پتروشیمی', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir', 'حسن - رضایی', 'danesh-yar'),
('5084710430', 26001, 'علي كرم', '1322-01-01', '9921210974', 'مهندسی برق - قدرت', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir', 'علیرضا - مرادی', 'ostad'),
('6343392956', 26002, 'حیاتقلی', '1352-10-03', '9082005573', 'مهندسی برق - قدرت', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir', 'علیرضا - حسن زاده', 'danesh-yar'),
('9738859065', 31001, 'حسين ', '1349-11-21', '09967513400', 'مهندسی کامپیوتر - هوش مصنوعی', '$2y$10$R4PHhQOzM2/1i4QBkBEHie7Wao5WCyPal6bEkxxcoa0XSvdy5Oj82', 'email@aut.ac.ir', 'عباس - رستمی', 'ostad'),
('3024641054', 31002, 'محمد', '1350-04-25', '9989393354', 'مهندسی کامپیوتر - هوش مصنوعی', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir', 'عباس - باقری نژاد', 'ostad'),
('9122447368', 31003, 'مندني', '1352-10-25', '9973391432', 'مهندسی کامپیوتر - نرم افزار', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir', 'مجید - عباسی', 'ostad-yar'),
('6825225184', 31004, 'حسين', '1347-04-19', '9381553708', 'مهندسی کامپیوتر - شبکه‌های کامپیوتری', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir', 'حسن - بامری', 'danesh-yar');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `name` varchar(255) NOT NULL,
  `national_code` varchar(10) NOT NULL,
  `student_no` int(7) NOT NULL,
  `father_name` varchar(255) NOT NULL,
  `birth_date` date NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `major` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`name`, `national_code`, `student_no`, `father_name`, `birth_date`, `mobile`, `major`, `password`, `email`) VALUES
('محسن - اسلامی', '2744740129', 9212001, 'براتعلی', '1374-10-18', '09971357179', 'مهندسی صنایع', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('امین - بریهی', '6674691878', 9212002, 'محمد', '1374-07-01', '09953808828', 'مهندسی صنایع', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('رضا - پاك فطرت', '6423500837', 9212003, 'علي اكبر', '1374-02-01', '09972361220', 'مهندسی صنایع', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('جواد - خادمی', '1422722578', 9212004, 'محمدصادق ', '1374-02-20', '09948247653', 'مهندسی صنایع', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('علی - رحمانی', '6486443272', 9212005, 'محمود', '1374-01-02', '09037225652', 'مهندسی صنایع', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('حسین - رحیمی', '2889059671', 9212006, 'رحيم', '1374-06-07', '09036084386', 'مهندسی صنایع', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('محسن - رضایی', '7098350928', 9212007, 'كريم', '1374-05-01', '09376859848', 'مهندسی صنایع', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('مهدی - سلمان پور', '4066435866', 9212008, 'حمزه علي', '1374-08-01', '09129188013', 'مهندسی صنایع', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('محمد - سنگرزاده', '7844087533', 9212009, 'نورمحمد', '1374-07-12', '09111269156', 'مهندسی صنایع', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('محسن - شاه حسینی', '1996537786', 9212010, 'نمام', '1374-12-12', '09166809527', 'مهندسی صنایع', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('مجید - شمس آبادی', '1398159943', 9212011, 'بايرامعلي ', '1374-07-01', '09999224636', 'مهندسی صنایع', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('مهدی - صیادی', '5900661576', 9212012, 'حسين', '1374-03-09', '09954358890', 'مهندسی صنایع', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('حسن - عسکرزاده', '6178468898', 9212013, 'رضا', '1374-05-01', '09052414745', 'مهندسی صنایع', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('محمد - فتحی', '5632586884', 9212014, 'شهاب الدين', '1374-09-16', '09187789246', 'مهندسی صنایع', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('علی - فردوس پور', '8204575138', 9212015, 'سید حسین', '1374-01-02', '09921722286', 'مهندسی صنایع', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('حسن - قلعه خانی', '3124914491', 9212016, 'نبي اله ', '1374-03-01', '09066999109', 'مهندسی صنایع', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('علیرضا - قنبری ', '9729840267', 9212017, 'گودرز ', '1374-08-02', '09075845707', 'مهندسی صنایع', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('علیرضا - كرامت پور', '5718970544', 9212018, 'محمد', '1374-09-16', '09967436736', 'مهندسی صنایع', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('رضا - مختار پور ', '7912849251', 9212019, 'غلامرضا', '1374-06-02', '09933261978', 'مهندسی صنایع', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('محمد - نجمی', '8683570122', 9212020, 'محمدعلي', '1374-09-19', '09911276958', 'مهندسی صنایع', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('رضا - بیدخوری', '6682796319', 9217001, 'حجت', '1374-12-20', '09014150099', 'مهندسی شیمی', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('محمد - پاشازاده', '2376967494', 9217002, 'رضا', '1374-02-11', '09983283747', 'مهندسی شیمی', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('حامد - تقوی', '4650210511', 9217003, 'علی', '1374-06-01', '09917575418', 'مهندسی شیمی', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('محمد - جعفری', '9254836356', 9217004, 'محمد', '1374-01-03', '09972924989', 'مهندسی شیمی', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('جواد - حاجی حسینی', '1345683898', 9217005, 'محمود ', '1374-12-20', '09135229623', 'مهندسی شیمی', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('علی - حبیبی', '2798012329', 9217006, 'محرمعلي ', '1374-02-01', '09967381544', 'مهندسی شیمی', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('محمدرضا - خادم', '9494985220', 9217007, 'محمدحسين', '1374-02-26', '09948123057', 'مهندسی شیمی', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('حسن - خوش خلق', '1885502950', 9217008, 'يوسف ', '1374-06-28', '09996028479', 'مهندسی شیمی', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('داود -  شراهی', '4614900789', 9217009, 'شهريار', '1374-06-25', '09131005237', 'مهندسی شیمی', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('حسین - رنگ آور', '2833532597', 9217010, 'غلامحيدر', '1374-11-20', '09358742865', 'مهندسی شیمی', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('مهدی - صالحی راد', '7379366511', 9217011, 'فضلعلی', '1374-05-17', '09936272686', 'مهندسی شیمی', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('محمدرضا - عربی', '2918170088', 9217012, 'اسداله ', '1374-10-02', '09947322136', 'مهندسی شیمی', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('مهدی - علی اکبری', '3955934714', 9217013, 'عظیم', '1374-07-12', '09936745508', 'مهندسی شیمی', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('حسین - كرمی ', '4554014912', 9217014, 'محمد', '1374-09-03', '09083556307', 'مهندسی شیمی', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('عباس - محمودی', '4801615804', 9217015, 'سلطانعلي ', '1374-12-01', '09350559804', 'مهندسی شیمی', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('علیرضا - اباذری', '6384141134', 9226001, 'موسي', '1374-08-29', '09967732004', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('جواد - آرونی', '6576538647', 9226002, 'حسن ', '1374-02-14', '09971253686', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('رضا - بختیاری', '2413823565', 9226003, 'مهدي', '1374-12-01', '09963616683', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('سجاد - ترکاشوند', '9169579526', 9226004, 'علي ', '1374-08-15', '09074450716', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('حمید - حسن زاده', '3557077128', 9226005, 'محمود', '1374-06-15', '09049709006', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('حمید - حیدری', '5210380003', 9226006, 'محمود', '1374-06-02', '09990039348', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('حسن - ربیعیان ', '8018258632', 9226007, 'قربان محمد', '1374-12-19', '09938704315', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('احمد - رکنی', '9750294605', 9226008, 'الهويردي', '1374-03-22', '09983568639', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('احمد - سیف زاده', '8275492166', 9226009, 'اكبر ', '1374-06-30', '09077811190', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('مهدی - عبد یزدان', '3266721217', 9226010, 'غلامعلي', '1374-02-25', '09317285227', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('علی -  سلیمانی', '9471257997', 9226011, 'محمد', '1374-06-23', '09111603887', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('رضا - قاسمی', '8186411273', 9226012, 'فيروز ', '1374-12-10', '09179117262', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('علیرضا - کرونی', '9190281708', 9226013, 'ابراهيم', '1374-01-02', '09933090187', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('داود - کیانی', '4704940353', 9226014, 'خيراله ', '1374-10-13', '09322472518', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('جواد - محمدی', '3863438162', 9226015, 'عربعلي ', '1374-02-23', '09063615006', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('محمد - محمدی', '8066356210', 9226016, 'اكبر', '1374-12-05', '09989566192', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('حسین - مرادی ', '3326878757', 9226017, 'غلامحسين', '1374-02-16', '09952151932', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('محمد - مشهدی', '5607472888', 9226018, 'ابراهيم', '1374-06-30', '09358672952', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('مهدی - منگلی', '8412703326', 9226019, 'خسرو ', '1374-09-01', '09312419080', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('علیرضا - میری', '1808853991', 9226020, 'علي', '1374-06-09', '09978746050', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('مجید - هاشمی', '6287979473', 9226021, 'غلام', '1374-08-15', '09949061537', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('علی - هاشمی', '3565817676', 9226022, 'قربانعلي', '1374-08-08', '09330636041', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('محمد - هراتی', '4792587094', 9226023, 'نظر ', '1374-10-14', '09947963426', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('محمد - همایونفرد ', '2771767191', 9226024, 'حسين', '1374-12-13', '09925098885', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('حسین - یزدانی', '7931968268', 9226025, 'نجف علي', '1374-06-01', '09938912513', 'مهندسی برق', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('حمید - اعلم', '1696528178', 9231001, 'شيخمراد', '1374-04-20', '09365910930', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('سعید - جوهر', '3405530731', 9231002, 'فرهاد', '1374-12-01', '09338156068', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('حسن - چانوری ', '3825395822', 9231003, 'حسنقلي', '1374-11-15', '09378264722', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('علی - حسنوند', '9979149227', 9231004, 'اسداله ', '1374-01-29', '09316867728', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('علی - حمیدیان', '8186549772', 9231005, 'زین العابدین', '1374-09-04', '09337593133', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('حسین - حیدری', '6157494803', 9231006, 'مانده علي', '1374-12-10', '09045749965', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('احمد - رباط ', '8809363872', 9231007, 'مرتضي', '1374-03-01', '09950558922', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('وحید - رستمی', '8580902696', 9231008, 'محمد ', '1374-06-20', '09023833390', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('احمد - رهبر', '4398140858', 9231009, 'ابراهيم ', '1374-07-01', '09083069699', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('احمد - ریگی ', '8453259948', 9231010, 'عید محمد', '1374-04-03', '09188577673', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('علی - ریوندی', '9137834853', 9231011, 'براتعلي', '1374-03-01', '09935751111', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('محمد - زنگنه', '2371877843', 9231012, 'يداله', '1374-11-01', '09999431462', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('محمدرضا - سلیمانی ', '9804039716', 9231013, 'غلام حسين', '1374-08-01', '09974222075', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('جواد - سلیمی', '6727665627', 9231014, 'صالح ', '1374-06-01', '09070229660', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('محسن - شجراوی', '5108782929', 9231015, 'عباس ', '1374-06-15', '09331362564', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('حسین - عبادی ', '3894796555', 9231016, 'قوچعلي', '1374-08-06', '09934359183', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('علی - عبدالخانی', '5561372010', 9231017, 'صفرعلي', '1374-06-10', '09954967361', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('سعید - فخاری', '4607300749', 9231018, 'مسلم', '1374-03-01', '09378961174', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('مجید - فضلی', '6924387793', 9231019, 'مهدي', '1374-10-10', '09934980625', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('جواد - قدرت', '6207876009', 9231020, 'علي ', '1374-06-30', '09144091070', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('حسین - قنبری ', '7800437364', 9231021, 'يداله', '1374-12-07', '09338530670', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('رضا - كهزاد', '1670072205', 9231022, 'علي بابا', '1374-09-08', '09129929838', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('عباس - کاربخش', '8417501701', 9231023, 'حسن', '1374-08-01', '09934016793', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('حامد - مظلومی', '4393208125', 9231024, 'موسي', '1374-07-03', '09077923302', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('احمد - مقدسی', '7572394244', 9231025, 'سید خلیل', '1374-03-20', '09097785414', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('حمید - مهجور', '3130293946', 9231026, 'محمدعلي', '1374-01-02', '09131138718', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('سعید - نادری', '3273452275', 9231027, 'طوغان ', '1374-06-21', '09956476676', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('علیرضا - ناصریان', '2243110868', 9231028, 'تيمور', '1374-09-07', '09990630056', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('مهدی - نوری', '9314560254', 9231029, 'محمد حسن ', '1374-04-24', '09974409571', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir'),
('محسن - یزدانی', '5165067811', 9231030, 'نظرعلي', '1374-06-01', '09043353987', 'مهندسی کامپیوتر', '$2y$10$TY4lSyBPx/UWvoGN7ceokeidGPpEuaudYIjmPN2OWvQhf8/DRB9ai', 'email@aut.ac.ir');

-- --------------------------------------------------------

--
-- Table structure for table `student_exercise_score`
--

CREATE TABLE `student_exercise_score` (
  `student_no` int(11) NOT NULL,
  `exercise_id` int(11) NOT NULL,
  `score` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `takes`
--

CREATE TABLE `takes` (
  `taking_id` int(11) NOT NULL,
  `course_id` int(10) NOT NULL,
  `student_id` int(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `takes`
--

INSERT INTO `takes` (`taking_id`, `course_id`, `student_id`) VALUES
(2, 31000010, 9231020),
(3, 31000010, 9231012),
(4, 17000005, 9217004),
(5, 12000005, 9212007),
(6, 31000005, 9231022),
(7, 26000003, 9226013),
(8, 31000002, 9231029),
(9, 26000003, 9226012),
(10, 12000004, 9212010),
(11, 31000007, 9231024),
(12, 31000004, 9231006),
(13, 26000003, 9226018),
(14, 31000004, 9231008),
(15, 17000004, 9217004),
(16, 17000004, 9217011),
(17, 31000009, 9231001),
(18, 31000009, 9231030),
(19, 31000006, 9231024),
(20, 31000004, 9231012),
(21, 31000011, 9231028),
(22, 26000003, 9226003),
(23, 26000003, 9226011),
(24, 17000003, 9217006),
(25, 31000003, 9231022),
(26, 31000008, 9231011),
(27, 31000011, 9231006),
(28, 31000004, 9231029),
(29, 31000013, 9231016),
(30, 31000007, 9231014),
(31, 31000011, 9231003),
(32, 31000005, 9231027),
(33, 26000001, 9226017),
(34, 31000002, 9231025),
(35, 17000004, 9217008),
(36, 26000005, 9226001),
(37, 12000004, 9212013),
(38, 26000003, 9226009),
(39, 31000009, 9231002),
(40, 26000003, 9226020),
(41, 12000003, 9212002),
(42, 17000001, 9217001),
(43, 12000002, 9212020),
(44, 31000008, 9231016),
(45, 12000003, 9212003),
(46, 26000005, 9226018),
(47, 31000007, 9231010),
(48, 31000010, 9231027),
(49, 31000011, 9231015),
(50, 12000006, 9212020),
(51, 12000001, 9212015),
(52, 31000013, 9231008),
(53, 31000012, 9231030),
(54, 31000013, 9231015),
(55, 12000003, 9212008),
(56, 31000001, 9231014),
(57, 31000004, 9231022),
(58, 12000005, 9212001),
(59, 12000001, 9212019),
(60, 26000002, 9226009),
(61, 17000003, 9217010),
(62, 31000011, 9231009),
(63, 31000009, 9231027),
(64, 31000012, 9231026),
(65, 31000005, 9231013),
(66, 31000013, 9231002),
(67, 31000006, 9231023),
(68, 26000002, 9226007),
(69, 26000002, 9226016),
(70, 12000001, 9212005),
(71, 17000004, 9217006),
(72, 26000004, 9226022),
(73, 12000005, 9212011),
(74, 31000009, 9231029),
(75, 31000004, 9231002),
(76, 17000004, 9217014),
(77, 31000008, 9231001),
(78, 12000003, 9212014),
(79, 26000004, 9226020),
(80, 31000008, 9231017),
(81, 31000013, 9231003),
(82, 31000001, 9231026),
(83, 17000006, 9217006),
(84, 31000003, 9231007),
(85, 31000011, 9231008),
(86, 31000005, 9231017),
(87, 31000004, 9231019),
(88, 12000006, 9212007),
(89, 31000004, 9231020),
(90, 26000001, 9226023),
(91, 26000001, 9226010),
(92, 31000002, 9231008),
(93, 31000001, 9231008),
(94, 26000002, 9226018),
(95, 12000004, 9212006),
(96, 31000001, 9231005),
(97, 31000001, 9231021),
(98, 12000001, 9212013),
(99, 31000010, 9231004),
(100, 31000005, 9231003),
(101, 12000001, 9212002),
(102, 31000013, 9231004),
(103, 17000006, 9217004),
(104, 31000002, 9231007),
(105, 17000001, 9217008),
(106, 31000001, 9231004),
(107, 31000009, 9231025),
(108, 17000004, 9217001),
(109, 31000007, 9231023),
(110, 26000002, 9226008),
(111, 31000001, 9231009),
(112, 17000002, 9217007),
(113, 26000005, 9226025),
(114, 31000007, 9231019),
(115, 31000004, 9231003),
(116, 31000001, 9231020),
(117, 31000011, 9231002),
(118, 31000002, 9231018),
(119, 12000001, 9212007),
(120, 31000011, 9231016),
(121, 12000002, 9212018),
(122, 31000009, 9231022),
(123, 12000004, 9212018),
(124, 31000008, 9231028),
(125, 31000004, 9231028),
(126, 31000004, 9231007),
(127, 31000010, 9231006),
(128, 31000010, 9231014),
(129, 17000004, 9217012),
(130, 31000010, 9231016),
(131, 31000007, 9231030),
(132, 12000006, 9212006),
(133, 31000007, 9231013),
(134, 17000004, 9217013),
(135, 17000002, 9217010),
(136, 31000008, 9231012),
(137, 31000008, 9231018),
(138, 17000002, 9217008),
(139, 17000006, 9217008),
(140, 31000006, 9231011),
(141, 12000003, 9212018),
(142, 31000013, 9231023),
(143, 31000009, 9231010),
(144, 12000001, 9212008),
(145, 31000001, 9231011),
(146, 31000013, 9231013),
(147, 26000004, 9226009),
(148, 12000004, 9212011),
(149, 12000004, 9212008),
(150, 26000001, 9226019),
(151, 31000005, 9231026),
(152, 31000008, 9231014),
(153, 26000004, 9226019),
(154, 12000004, 9212020),
(155, 31000010, 9231028),
(156, 17000003, 9217012),
(157, 26000002, 9226023),
(158, 31000001, 9231006),
(159, 31000002, 9231013),
(160, 31000005, 9231028),
(161, 31000004, 9231025),
(162, 26000005, 9226012),
(163, 31000003, 9231010),
(164, 12000005, 9212004),
(165, 17000004, 9217005),
(166, 31000002, 9231024),
(167, 31000013, 9231017),
(168, 26000003, 9226016),
(169, 12000004, 9212009),
(170, 31000011, 9231011),
(171, 26000003, 9226002),
(172, 31000004, 9231026),
(173, 31000001, 9231013),
(174, 31000012, 9231014),
(175, 26000005, 9226010),
(176, 31000002, 9231010),
(177, 12000006, 9212014),
(178, 31000006, 9231019),
(179, 12000003, 9212020),
(180, 31000003, 9231020),
(181, 12000005, 9212017),
(182, 31000003, 9231004),
(183, 26000002, 9226003),
(184, 12000006, 9212012),
(185, 12000006, 9212008),
(186, 31000008, 9231015),
(187, 31000008, 9231002),
(188, 31000012, 9231015),
(189, 26000003, 9226008),
(190, 31000009, 9231014),
(191, 12000004, 9212005),
(192, 31000012, 9231024),
(193, 17000001, 9217007),
(194, 17000001, 9217004),
(195, 31000012, 9231028),
(196, 17000006, 9217005),
(197, 31000012, 9231009),
(198, 26000005, 9226019),
(199, 31000010, 9231025),
(200, 31000006, 9231005),
(201, 31000007, 9231012),
(202, 26000001, 9226025),
(203, 31000009, 9231015),
(204, 12000005, 9212002),
(205, 26000004, 9226001),
(206, 31000012, 9231011),
(207, 26000003, 9226019),
(208, 17000002, 9217012),
(209, 31000005, 9231025),
(210, 26000001, 9226004),
(211, 17000006, 9217007),
(212, 31000001, 9231003),
(213, 31000012, 9231020),
(214, 31000003, 9231024),
(215, 31000013, 9231021),
(216, 31000001, 9231023),
(217, 31000008, 9231020),
(218, 31000010, 9231005),
(219, 31000008, 9231006),
(220, 31000005, 9231002),
(221, 31000008, 9231019),
(222, 31000009, 9231017),
(223, 12000004, 9212012),
(224, 31000007, 9231020),
(225, 26000003, 9226021),
(226, 31000012, 9231022),
(227, 31000009, 9231004),
(228, 31000011, 9231007),
(229, 31000008, 9231008),
(230, 12000004, 9212017),
(231, 31000007, 9231004),
(232, 26000004, 9226017),
(233, 12000002, 9212001),
(234, 26000004, 9226003),
(235, 17000001, 9217011),
(236, 12000001, 9212017),
(237, 12000002, 9212017),
(238, 31000003, 9231009),
(239, 31000009, 9231009),
(240, 31000003, 9231003),
(241, 26000002, 9226014),
(242, 31000006, 9231004),
(243, 26000002, 9226020),
(244, 17000003, 9217015),
(245, 31000011, 9231004),
(246, 17000006, 9217014),
(247, 31000008, 9231029),
(248, 31000010, 9231015),
(249, 31000010, 9231011),
(250, 31000003, 9231023),
(251, 26000002, 9226010),
(252, 31000013, 9231011),
(253, 12000004, 9212007),
(254, 26000005, 9226015),
(255, 31000012, 9231008),
(256, 31000008, 9231026),
(257, 31000007, 9231027),
(258, 31000002, 9231022),
(259, 31000004, 9231018),
(260, 31000008, 9231013),
(261, 17000003, 9217013),
(262, 31000005, 9231016),
(263, 31000001, 9231017),
(264, 31000002, 9231028),
(265, 26000004, 9226002),
(266, 31000001, 9231027),
(267, 31000007, 9231009),
(268, 31000004, 9231005),
(269, 12000006, 9212002),
(270, 26000005, 9226002),
(271, 31000005, 9231005),
(272, 31000005, 9231014),
(273, 12000006, 9212018),
(274, 31000012, 9231018),
(275, 31000006, 9231014),
(276, 26000003, 9226024),
(277, 31000011, 9231027),
(278, 31000010, 9231003),
(279, 31000005, 9231004),
(280, 12000001, 9212016),
(281, 17000006, 9217012),
(282, 17000005, 9217014),
(283, 26000005, 9226016),
(284, 31000008, 9231023),
(285, 31000001, 9231025),
(286, 12000005, 9212019),
(287, 31000006, 9231007),
(288, 31000002, 9231009),
(289, 12000003, 9212001),
(290, 31000004, 9231014),
(291, 12000003, 9212006),
(292, 31000001, 9231030),
(293, 31000013, 9231009),
(294, 17000003, 9217007),
(295, 31000008, 9231027),
(296, 12000002, 9212012),
(297, 26000002, 9226025),
(298, 31000010, 9231013),
(299, 17000002, 9217015),
(300, 31000011, 9231021),
(301, 17000002, 9217004),
(302, 31000009, 9231018),
(303, 31000003, 9231016),
(304, 31000004, 9231004),
(305, 17000002, 9217006),
(306, 31000012, 9231007),
(307, 31000006, 9231010),
(308, 26000001, 9226008),
(309, 31000011, 9231013),
(310, 31000008, 9231025),
(311, 31000004, 9231009),
(312, 26000005, 9226006),
(313, 31000005, 9231019),
(314, 26000002, 9226021),
(315, 31000012, 9231006),
(316, 26000005, 9226022),
(317, 31000011, 9231019),
(318, 31000009, 9231005),
(319, 31000007, 9231015),
(320, 31000005, 9231010),
(321, 31000008, 9231004),
(322, 31000007, 9231005),
(323, 31000002, 9231015),
(324, 12000003, 9212015),
(325, 17000002, 9217013),
(326, 17000001, 9217010),
(327, 26000003, 9226010),
(328, 31000006, 9231001);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_id`),
  ADD KEY `PROF` (`prof_no`);

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`exam_id`);

--
-- Indexes for table `exam_questions`
--
ALTER TABLE `exam_questions`
  ADD PRIMARY KEY (`exam_question_id`);

--
-- Indexes for table `exam_question_answers`
--
ALTER TABLE `exam_question_answers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam_student_score`
--
ALTER TABLE `exam_student_score`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exercises`
--
ALTER TABLE `exercises`
  ADD PRIMARY KEY (`exercise_id`);

--
-- Indexes for table `exercise_questions`
--
ALTER TABLE `exercise_questions`
  ADD PRIMARY KEY (`exercise_id`,`question_text`);

--
-- Indexes for table `exercise_question_answer`
--
ALTER TABLE `exercise_question_answer`
  ADD PRIMARY KEY (`exercise_id`);

--
-- Indexes for table `professors`
--
ALTER TABLE `professors`
  ADD PRIMARY KEY (`professor_no`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_no`);

--
-- Indexes for table `student_exercise_score`
--
ALTER TABLE `student_exercise_score`
  ADD PRIMARY KEY (`student_no`,`exercise_id`);

--
-- Indexes for table `takes`
--
ALTER TABLE `takes`
  ADD PRIMARY KEY (`taking_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `exams`
--
ALTER TABLE `exams`
  MODIFY `exam_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exam_questions`
--
ALTER TABLE `exam_questions`
  MODIFY `exam_question_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exam_question_answers`
--
ALTER TABLE `exam_question_answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exam_student_score`
--
ALTER TABLE `exam_student_score`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exercises`
--
ALTER TABLE `exercises`
  MODIFY `exercise_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `exercise_questions`
--
ALTER TABLE `exercise_questions`
  MODIFY `exercise_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `takes`
--
ALTER TABLE `takes`
  MODIFY `taking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=329;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `PROF` FOREIGN KEY (`prof_no`) REFERENCES `professors` (`professor_no`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
