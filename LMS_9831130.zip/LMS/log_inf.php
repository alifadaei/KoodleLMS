<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "lms_koodle";
$conn = mysqli_connect($servername, $username, $password, $db);
